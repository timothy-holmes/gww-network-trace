import gww_gis_tools


def test_version():
    assert gww_gis_tools.__version__ == "0.2.0"
