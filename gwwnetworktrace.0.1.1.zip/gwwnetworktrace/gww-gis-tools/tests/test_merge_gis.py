import gww_gis_tools.merge_gis.merge_sewer as MS


class TestDummy:
    def __init__(self):
        pass


class TestExtract:
    pass
